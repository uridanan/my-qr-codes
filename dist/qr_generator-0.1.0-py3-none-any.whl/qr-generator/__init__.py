# qr_generator/__init__.py
from .qrcodes import generate_qr_code_with_logo  # Example: Import the main function
from .jsoninputfile import read_json_from_file, get_json_value # Example: Import from utils